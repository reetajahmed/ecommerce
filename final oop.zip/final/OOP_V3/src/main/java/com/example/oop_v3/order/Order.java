package com.example.oop_v3.order;
import com.example.oop_v3.customer.Customer;
import com.example.oop_v3.person.Person;
import com.example.oop_v3.product.Product;
import com.example.oop_v3.payments.Payments;
import com.example.oop_v3.cashOnDeliveryPayment.CashOnDeliveryPayment;
import com.example.oop_v3.creditCard.CreditCard;
import com.example.oop_v3.cart.Cart;

import java.util.List;
import java.util.Scanner;

public class Order {
    private int orderId;
    private List<Product> products; // Products in the order
    private List<Integer> quantities; // Quantities of each product in the order
    private double totalAmount; // Total amount of the order
    private Payments paymentMethod; // Payment method chosen
    private boolean isOrderPlaced; // Flag to track order status
    private Customer customer; // Customer who placed the order

    // Constructor accepting a Cart and Customer
    public Order(int orderId, Cart cart, Customer customer) {
        this.orderId = orderId;
        this.products = cart.getProducts(); // Get products from the cart
        this.quantities = cart.getQuantities(); // Get quantities from the cart
        this.totalAmount = cart.getTotalPrice(); // Get total price from the cart
        this.customer = customer; // Assign the customer
        this.isOrderPlaced = false; // Initially, the order is not placed
    }

    public int getOrderId() {
        return orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public Payments getPaymentMethod() {
        return paymentMethod;
    }

    // Display order details
    public void displayOrderDetails() {
        System.out.println("=================================");
        System.out.println("           Order Details         ");
        System.out.println("=================================");
        System.out.printf("Order ID: %d%n", orderId);
        System.out.println("Customer Username: " + customer.getUsername());  // Display customer username
        System.out.println("Customer Address: " + customer.getAddress());
        System.out.println("---------------------------------");
        System.out.printf("%-20s%-10s%-10s%n", "Product Name", "Price", "Quantity");
        System.out.println("---------------------------------");

        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            int quantity = quantities.get(i);
            System.out.printf("%-20s%-10.2f%-10d%n",
                    product.getName(),
                    product.getPrice(),
                    quantity);
        }

        System.out.println("---------------------------------");
        System.out.printf("Total Amount: %.2f EGP%n", totalAmount);
        System.out.println("---------------------------------");

        if (paymentMethod != null) {
            System.out.println("Payment Method: " + paymentMethod.getMethodName());
        } else {
            System.out.println("Payment Method: Not Selected");
        }
        System.out.println("=================================");
    }

    // Ask for a payment method
    public void selectPaymentMethod() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("Select a Payment Method:");
                System.out.println("1. Credit Card");
                System.out.println("2. Cash on Delivery");

                int choice = Integer.parseInt(scanner.nextLine().trim()); // Validate integer input

                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter Credit Card Number (16 digits): ");
                        String cardNumber = scanner.nextLine();
                        System.out.print("Enter Card Holder Name: ");
                        String cardHolderName = scanner.nextLine();
                        System.out.print("Enter Expiry Date (MM/YY): ");
                        String expiryDate = scanner.nextLine();
                        this.paymentMethod = new CreditCard(cardNumber, cardHolderName, expiryDate);
                        return; // Exit the loop after successful input
                    }
                    case 2 -> {
                        this.paymentMethod = new CashOnDeliveryPayment();
                        return; // Exit the loop after successful input
                    }
                    default -> System.out.println("Invalid choice. Please select a valid payment method.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                System.out.println("Please re-enter the information.");
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }
    }

    // Place the order
    public void placeOrder() {
        if (paymentMethod == null) {
            System.out.println("Please select a payment method first.");
            return;
        }

        boolean paymentSuccessful = paymentMethod.paymentCompleted(totalAmount);
        if (paymentSuccessful) {
            System.out.println("Order placed successfully!");
            paymentMethod.displayDetails();
            isOrderPlaced = true;
        } else {
            System.out.println("Payment failed. Order not placed.");
        }
    }

    public void cancelOrder() {
        if (!isOrderPlaced) {
            System.out.println("No order to cancel.");
            return;
        }
        isOrderPlaced = false;
        System.out.println("The order has been canceled.");
    }


    // Display products in the cart
    public void displayProductsInCart() {
        System.out.println("=================================");
        System.out.println("           Cart Items           ");
        System.out.println("=================================");
        System.out.printf("%-20s%-10s%-10s%n", "Product Name", "Price", "Quantity");
        System.out.println("---------------------------------");

        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            int quantity = quantities.get(i);
            System.out.printf("%-20s%-10.2f%-10d%n",
                    product.getName(),
                    product.getPrice(),
                    quantity);
        }

        System.out.println("---------------------------------");
        System.out.printf("Total Amount: %.2f EGP%n", totalAmount);
        System.out.println("=================================");
    }
    public boolean isOrderPlaced() {
        return isOrderPlaced;
    }


}

