package com.example.oop_v3.cart;
import com.example.oop_v3.product.Product;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private List<Product> products; // List of products in the cart
    private List<Integer> quantities; // List of quantities for each product
    private double totalPrice; // Total price of the cart

    // Constructor
    public Cart() {
        this.products = new ArrayList<>();
        this.quantities = new ArrayList<>();
        this.totalPrice = 0.0;
    }

    // Method to add a product to the cart
    public void addItem(Product product, int quantity) {
        if (product != null && product.getStock() >= quantity) {
            // Check if product is already in the cart
            boolean productExists = false;
            for (int i = 0; i < products.size(); i++) {
                if (products.get(i).equals(product)) {
                    quantities.set(i, quantities.get(i) + quantity); // Increase the quantity
                    productExists = true;
                    break;
                }
            }

            // If the product is not in the cart, add it
            if (!productExists) {
                products.add(product);
                quantities.add(quantity);
            }

            this.totalPrice += product.getPrice() * quantity;
            product.updateStock(-quantity); // Decrease product stock
            System.out.println(quantity + " x " + product.getName() + " added to the cart.");
        } else {
            System.out.println("Product is unavailable or insufficient stock.");
        }
    }

    // Method to remove a product from the cart
    public void removeItem(Product product) {
        int index = products.indexOf(product);
        if (index != -1) {
            int quantity = quantities.get(index);
            this.totalPrice -= product.getPrice() * quantity;
            product.updateStock(quantity); // Restore the product stock
            products.remove(index);
            quantities.remove(index);
            System.out.println(product.getName() + " removed from the cart.");
        } else {
            System.out.println("Product is not in the cart.");
        }
    }

    // Method to calculate the total price of the cart
    public double calculateTotal() {
        return this.totalPrice;
    }

    // Method to display cart details
    public void displayCart() {
        if (products.isEmpty()) {
            System.out.println("The cart is empty.");
        } else {
            System.out.println("Cart Items:");
            for (int i = 0; i < products.size(); i++) {
                Product product = products.get(i);
                int quantity = quantities.get(i);
                System.out.println("- " + product.getName() + " | Price: " + product.getPrice() +
                        " | Quantity: " + quantity);
            }
            System.out.println("Total Price: " + calculateTotal());
        }
    }

    public void clear() {
        products.clear();
    }

    // Getters
    public List<Product> getProducts() {
        return products;
    }

    public List<Integer> getQuantities() {
        return quantities;
    }

    public double getTotalPrice() {
        return totalPrice;
    }
}
