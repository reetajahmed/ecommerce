package com.example.oop_v3.database;
import com.example.oop_v3.cart.Cart;
import com.example.oop_v3.customer.Customer;
import com.example.oop_v3.admin.Admin;
import com.example.oop_v3.person.Person;
import com.example.oop_v3.category.Category;
import com.example.oop_v3.product.Product;
import com.example.oop_v3.order.Order;
import java.util.ArrayList;
import java.util.List;


public class Database {
    private static List<Customer> customers = new ArrayList<>();
    private static List<Admin> admins = new ArrayList<>();
    private static List<Category> categories = new ArrayList<>();
    private static List<Product> products = new ArrayList<>();
    private static List<Order> orders = new ArrayList<>(); // New field for storing orders


    private static Database instance = null;

    public static synchronized Database getInstance() {
        if (instance == null) {
            instance = new Database();
            instance.initializeData(); // Call initialization after instance creation
        }
        return instance;
    }


    public List<Customer> getCustomers() {
        return customers;
    }
    public List<Order> getOrders() { // New method to get the list of orders
        return orders;
    }

    public List<Admin> getAdmins() {
        return admins;
    }

    public List<Category> getCategories() {
        return categories;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public void addAdmin(Admin admin) {
        admins.add(admin);
    }

    public void addCategory(Category category) {
        categories.add(category);
    }

    public void initializeData() {


            // Add default categories with background images
        addCategory(new Category("Gold Jewelry", "Luxurious gold necklaces, bracelets, and rings.", "/images/gold.jpg"));
        addCategory(new Category("Diamond Jewelry", "Elegant diamond rings, pendants, and earrings.", "/images/diamonds.jpg"));
        addCategory(new Category("Silver Jewelry", "Timeless and affordable silver jewelry collections.", "/images/silver.jpg"));



        // Get references to the created categories
        Category goldCategory = findCategoryByName("Gold Jewelry");
        Category diamondCategory = findCategoryByName("Diamond Jewelry");
        Category silverCategory = findCategoryByName("Silver Jewelry");

        // Add default products
        addProduct(new Product(1, "Multi-shaped Colored Stones Layered Necklace", 20000, 10, goldCategory,"/images/goldnecklace.png") ,"Gold Jewelry");
        addProduct(new Product(1, "Round Pearls Chain Bracelet", 4000, 10, goldCategory,"/images/goldbracelet.png"), "Gold Jewelry");
        addProduct(new Product(1, "Circle Colored Stones Hoop Earrings", 6700, 10, goldCategory,"/images/goldearrings.png"), "Gold Jewelry");
        addProduct(new Product(1, "Circle Colored Stones Ring ", 6000, 10, goldCategory,"/images/goldring.png"), "Gold Jewelry");
        addProduct(new Product(2, "Circle Diamond Necklace ", 160000, 5, diamondCategory,"/images/diamondnecklace.png"), "Diamond Jewelry");
        addProduct(new Product(5, "Cushion Diamond Ring", 70000, 6, diamondCategory,"/images/diamondring.png"), "Diamond Jewelry");
        addProduct(new Product(5, "Pear Diamond Chain Bracelet", 80000, 6, diamondCategory,"/images/diamondbracelet.png"), "Diamond Jewelry");
        addProduct(new Product(5, "Circle Diamond Drop Earrings", 130000, 6, diamondCategory,"/images/diamondearrings.png"), "Diamond Jewelry");
        addProduct(new Product(3, "Circular Pearl Necklace", 3000, 20, silverCategory,"/images/silvernecklace.png"), "Silver Jewelry");
        addProduct(new Product(3, "Baguette Silver Two-headed Ring", 1500, 20, silverCategory,"/images/silverring.png"), "Silver Jewelry");
        addProduct(new Product(3, "Brilliant Silver Chain Bracelet ", 2500, 20, silverCategory,"/images/silverbracelet.png"), "Silver Jewelry");
        addProduct(new Product(4, "Circle Silver Stud Earrings", 2000, 8, goldCategory,"/images/silverearrings.png"), "Silver Jewelry");

        addAdmin(new Admin("Monzer","Pass1@123","1/1/2005","idkyet", Person.Gender.MALE,"HR",5));
        addAdmin(new Admin("Nouran","Pass2@123","2/1/2005","idkyet", Person.Gender.FEMALE,"Store manager",8));
        addAdmin(new Admin("Hla","Pass2@123","1/9/2005","idkyet", Person.Gender.FEMALE,"Store manager",8));
        addAdmin(new Admin("Reetaj","Pass3@123","3/1/2005","idkyet", Person.Gender.FEMALE,"Finance",10));
        addCustomer(new Customer("john_doe", "Strong@123", "1/1/2005", "123 Elm Street", Person.Gender.MALE, 1500.0));
        addCustomer(new Customer("jane_smith", "Password#456", "1/1/2004", "456 Oak Avenue", Person.Gender.FEMALE, 2000.0));
        addCustomer(new Customer("alice_wonder", "Secure#789", "2/1/2005", "789 Maple Drive", Person.Gender.FEMALE, 1800.0));
        addCustomer(new Customer("charlie_brown", "MyPass@2023", "1/1/2003", "101 Pine Boulevard", Person.Gender.MALE, 1700.0));
        addCustomer(new Customer("dave_adams", "Welcome#321", "1/1/2003", "303 Cedar Lane", Person.Gender.MALE, 1400.0));

        addSampleOrders();
    }
    private void addSampleOrders() {
        // Create sample carts for customers
        Cart johnCart = new Cart();
        johnCart.addItem(findProductById(1), 2); // John buys 2 of product ID 1
        johnCart.addItem(findProductById(2), 1); // John buys 1 of product ID 2

        Cart janeCart = new Cart();
        janeCart.addItem(findProductById(3), 3); // Jane buys 3 of product ID 3

        Cart aliceCart = new Cart();
        aliceCart.addItem(findProductById(5), 1); // Alice buys 1 of product ID 5
        aliceCart.addItem(findProductById(2), 1); // Alice buys 1 of product ID 2

        Cart charlieCart = new Cart();
        charlieCart.addItem(findProductById(3), 1); // Charlie buys 1 of product ID 3
        charlieCart.addItem(findProductById(1), 2); // Charlie buys 2 of product ID 1

        // Add default orders
        orders.add(new Order(1, johnCart, findCustomerByUsername("john_doe")));
        orders.add(new Order(2, janeCart, findCustomerByUsername("jane_smith")));
        orders.add(new Order(3, aliceCart, findCustomerByUsername("alice_wonder")));
        orders.add(new Order(4, charlieCart, findCustomerByUsername("charlie_brown")));
    }

    public Category findCategoryByName(String categoryName) {
        return categories.stream()
                .filter(category -> category.getCategoryName().equalsIgnoreCase(categoryName))
                .findFirst()
                .orElse(null);
    }

    public void addProduct(Product product, String categoryName) {
        // Add the product to the global products list
        products.add(product);


        for (Category category : categories) {
            if (category.getCategoryName().equalsIgnoreCase(categoryName)) {

                if (category.getProducts() == null) {
                    category.setProducts(new ArrayList<>());  // Initialize the list if it's null
                }


                category.getProducts().add(product);
                product.setCategory(category);
                return;
            }
        }
        System.out.println("Category with name " + categoryName + " not found. Product not linked to any category.");
    }

    public Admin findAdminByUsernameAndPassword(String username, String password) {
        return admins.stream()
                .filter(admin -> admin.getUsername().equals(username) && admin.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }

    public Customer findCustomerByUsernameAndPassword(String username, String password) {
        return customers.stream()
                .filter(customer -> customer.getUsername().equals(username) && customer.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }


    public void addOrder(Order order) { // New method to add an order
        orders.add(order);
    }

    public Customer findCustomerByUsername(String username) {
        return customers.stream().filter(c -> c.getUsername().equals(username)).findFirst().orElse(null);
    }

    public Product findProductById(int id) {
        return products.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }
    public List<Category> getAllCategories() {
        return categories;
    }

}

