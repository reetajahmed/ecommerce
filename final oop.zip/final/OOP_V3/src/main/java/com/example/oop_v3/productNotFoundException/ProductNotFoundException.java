package com.example.oop_v3.productNotFoundException;

public class ProductNotFoundException extends Exception {
  public ProductNotFoundException(String message) {
    super(message);

  }
}
