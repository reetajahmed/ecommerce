package com.example.oop_v3.payments;

public interface Payments {
    boolean paymentCompleted(double amount);
    void displayDetails();
    String getMethodName();

}
