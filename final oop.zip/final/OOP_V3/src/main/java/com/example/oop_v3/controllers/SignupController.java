package com.example.oop_v3.controllers;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import com.example.oop_v3.person.Person;
import com.example.oop_v3.customer.Customer;

import javafx.scene.Parent;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;  // For handling IO exceptions
import java.lang.IllegalArgumentException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
public class SignupController {

    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;
    @FXML
    private TextField addressField;
    @FXML
    private ComboBox<String> genderComboBox;
    @FXML
    private DatePicker datePicker;
    @FXML
    private CheckBox goldCheckBox;
    @FXML
    private CheckBox diamondCheckBox;
    @FXML
    private CheckBox silverCheckBox;
    @FXML
    private ImageView backgroundImage;
    @FXML
    private StackPane rootPane;
    @FXML private Button gobackButton;

    @FXML
    public void handleGoBack(ActionEvent event) {
        try {
            // Load the home page FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/HomePage.fxml"));
            Parent homeScene = loader.load();

            // Get the current stage (window) and change the scene
            Stage stage = (Stage) gobackButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(homeScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.setTitle("Back Page");

            // Show the new scene (home page)
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            // Show error if something goes wrong
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("An error occurred while going back. Please try again.");
            alert.showAndWait();
        }
    }


    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void initialize() {
        if (datePicker != null) {
            datePicker.setValue(java.time.LocalDate.now());
        } else {
            System.out.println("DatePicker is null");
        }
        genderComboBox.getItems().addAll("Male", "Female");
        datePicker.setValue(LocalDate.now());
        backgroundImage.fitWidthProperty().bind(rootPane.widthProperty());
        backgroundImage.fitHeightProperty().bind(rootPane.heightProperty());
    }

    // Validation methods
    public String validateUsername(String username) throws IllegalArgumentException {
        if (username == null || username.isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty.");
        }
        if (username.length() < 5) {
            throw new IllegalArgumentException("Username must be at least 5 characters long.");
        }
        if (!username.matches("[a-zA-Z0-9_]+")) {
            throw new IllegalArgumentException("Username can only contain alphanumeric characters and underscores.");
        }
        return username;
    }

    public String validatePassword(String password) throws IllegalArgumentException {
        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty.");
        }
        if (password.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters long.");
        }
        if (!password.matches(".*[A-Z].*")) {  // Check for at least one uppercase letter
            throw new IllegalArgumentException("Password must contain at least one uppercase letter.");
        }
        if (!password.matches(".*[a-z].*")) {  // Check for at least one lowercase letter
            throw new IllegalArgumentException("Password must contain at least one lowercase letter.");
        }
        if (!password.matches(".*\\d.*")) {  // Check for at least one digit
            throw new IllegalArgumentException("Password must contain at least one digit.");
        }
        if (!password.matches(".*[@#$%^&+=].*")) {  // Check for at least one special character
            throw new IllegalArgumentException("Password must contain at least one special character (@, #, $, %, ^, &, +, =).");
        }
        return password;
    }


    @FXML
    private void handleSubmit() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String address = addressField.getText();
        String genderInput = genderComboBox.getValue();
        Person.Gender gender = null;
        LocalDate selectedDate = datePicker.getValue();
        boolean isGoldSelected = goldCheckBox.isSelected();
        boolean isDiamondSelected = diamondCheckBox.isSelected();
        boolean isSilverSelected = silverCheckBox.isSelected();

        try {
            // Validate inputs
            if (username.isEmpty()) {
                showAlert("Missing Username", "Username cannot be empty.");
                return;
            }
            validateUsername(username);

            if (password.isEmpty()) {
                showAlert("Missing Password", "Password cannot be empty.");
                return;
            }
            validatePassword(password);

            if (address.isEmpty()) {
                showAlert("Missing Address", "Address cannot be empty.");
                return;
            }

            if (genderInput == null) {
                showAlert("Missing Gender", "Gender must be selected.");
                return;
            }
            gender = Person.Gender.valueOf(genderInput.toUpperCase());

            if (selectedDate == null || selectedDate.isAfter(LocalDate.now())) {
                showAlert("Invalid Date", "Date of Birth cannot be in the future.");
                return;
            }
            long age = java.time.temporal.ChronoUnit.YEARS.between(selectedDate, LocalDate.now());
            if (age < 19) {
                showAlert("Invalid Age", "You must be at least 19 years old.");
                return;
            }

            if (!isGoldSelected && !isDiamondSelected && !isSilverSelected) {
                showAlert("Missing Interests", "At least one interest must be selected.");
                return;
            }

            // Prepare customer data
            double balance = 0;
            List<String> interestsList = new ArrayList<>();
            if (isGoldSelected) interestsList.add("Gold");
            if (isDiamondSelected) interestsList.add("Diamond");
            if (isSilverSelected) interestsList.add("Silver");
            String[] interests = interestsList.toArray(new String[0]);

            String dateOfBirth = selectedDate.toString();

            // Add customer to the database (simulated)
            Customer newCustomer = new Customer(username, password, dateOfBirth, address, gender, balance, interests);
            showAlert("Success", "New customer has been added to the database!");

            // Navigate to the home page
            navigateToHomePage();

        } catch (IllegalArgumentException e) {
            showAlert("Validation Error", e.getMessage());
        } catch (Exception e) {
            showAlert("Error", "Failed to add the customer: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void navigateToHomePage() {
        try {
            // Load the home page FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/HomePage.fxml"));
            Parent homePage = loader.load();

            Stage stage = (Stage) rootPane.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene
            Scene scene = new Scene(homePage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.setTitle("Home Page");

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load home page.");
        }
    }
}