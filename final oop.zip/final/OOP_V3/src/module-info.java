module com.example.oop_v3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.oop_v3 to javafx.fxml;
    exports com.example.oop_v3;
    exports com.example.oop_v3.customer;
    opens com.example.oop_v3.customer to javafx.fxml;
}


