package com.example.oop_v3.controllers;


import com.example.oop_v3.database.Database;
import com.example.oop_v3.product.Product;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;


import java.io.IOException;
import java.util.List;

public class ProductPageController {

    private String selectedCategoryName;

    @FXML
    private ScrollPane productsScrollPane;

    @FXML
    private Label messageLabel;


    @FXML
    private Button loginButton;

    @FXML
    private Button registerButton;

    @FXML
    private Button backButton;


    public void initialize(String categoryName) {

        selectedCategoryName = categoryName;
        loadProducts();

    }
    @FXML
    private void handleBack() {
        try {
            // Load the Category or Home Page FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/HomePage.fxml")); // Adjust path accordingly
            Parent homepage = loader.load();

            // Get the current stage (window) and set the new scene
            Stage stage = (Stage) backButton.getScene().getWindow(); // You can use any other control that's already part of the scene

            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene
            Scene scene = new Scene(homepage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the FXML file is not found or there's an error loading it
        }
    }



    // Handle the Login button action
    @FXML
    private void handleLogin()
    {
        try {
            // Load the Login FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/login.fxml"));
            Parent loginPage = loader.load(); // Use Parent to avoid casting issues

            // Get the current stage (window) and set the new scene
            Stage stage = (Stage) loginButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene
            Scene scene = new Scene(loginPage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the FXML file is not found or there's an error loading it
        }
    }

    // Handle the Register button action
    @FXML
    private void handleRegister() {
        try {
            // Load the Signup FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/Signup.fxml"));
            Parent signupPage = loader.load();

            // Get the current stage (window) and set the new scene
            Stage stage = (Stage) registerButton.getScene().getWindow();

            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene
            Scene scene = new Scene(signupPage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the fxml file is not found or there's an error loading it
        }
    }



    private void loadProducts() {
        // Ensure ScrollPane has a container for products
        FlowPane productsFlowPane = new FlowPane();
        productsFlowPane.setHgap(20); // Horizontal gap between products
        productsFlowPane.setVgap(20); // Vertical gap between rows
        productsScrollPane.setContent(productsFlowPane);



        Database database = Database.getInstance();
        List<Product> products = database.findCategoryByName(selectedCategoryName).getProducts();

        if (products == null || products.isEmpty()) {
            if (messageLabel != null) {
                messageLabel.setText("No products available in this category.");
            }
            return;
        }

        for (Product product : products) {
            VBox productBox = createProductBox(product);
            productsFlowPane.getChildren().add(productBox);
        }
    }

    private VBox createProductBox(Product product) {
        VBox productBox = new VBox();
        productBox.setSpacing(10);
        productBox.setAlignment(javafx.geometry.Pos.CENTER);

        double boxWidth = 412.5;
        double boxHeight = 275;
        productBox.setPrefSize(boxWidth, boxHeight);

        Rectangle clip = new Rectangle(boxWidth, boxHeight);
        clip.setArcWidth(60);
        clip.setArcHeight(60);
        productBox.setClip(clip);

        if (product.getImagePath() != null && !product.getImagePath().isEmpty()) {
            productBox.setStyle("-fx-background-image: url('" + product.getImagePath() + "');"
                    + "-fx-background-size: cover; -fx-background-radius: 30; -fx-background-insets: 0;"
                    + "-fx-border-color: #d8bfd8; -fx-border-width: 2; -fx-border-radius: 30; -fx-padding: 15;");
        } else {
            productBox.setStyle("-fx-background-color: rgba(138, 43, 226, 0.8);"
                    + "-fx-border-color: #d8bfd8; -fx-border-width: 2; -fx-border-radius: 30; -fx-background-radius: 30;"
                    + "-fx-padding: 15;");
        }

        Text productName = new Text(product.getName());
        productName.setStyle("-fx-font-size: 15px; -fx-font-weight: 900; -fx-fill: rgb(75, 0, 135); -fx-font-family: 'Lucida Calligraphy';");

        Text productPrice = new Text("Price: " + product.getPrice());
        productPrice.setStyle("-fx-font-size: 12px; -fx-fill: rgb(75, 0, 135);");



        productBox.getChildren().addAll(productName, productPrice);
        return productBox;
    }


}
