package com.example.oop_v3.product;
import com.example.oop_v3.category.Category;

public class Product {
    private int id;
    private String name;
    private double price;
    private int stock;
    private Category category;
    private String imagePath;

    public Product(){}

    public Product(String name, int stock, double price)
    {

        this.name = name;
        this.price = price;
        this.stock = stock;

    }

    public Product(int id, String name, double price, int stock, Category category) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.category = category;
    }
    public Product(int id, String name, double price, int stock, Category category,String imagePath) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.category = category;
        this.imagePath = imagePath;


    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
    public String getImagePath() {return imagePath;}

    // Function to update the stock
    public void updateStock(int stock)
    {
        if (stock < 0 && Math.abs(stock) > this.stock) {
            System.out.println("Insufficient stock to remove.");
        }
        else
        {
            this.stock += stock;
            System.out.println("Stock updated.\nNew stock: " + this.stock);
        }
    }


}

