package com.example.oop_v3.controllers;

import com.example.oop_v3.admin.Admin;

import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.List;

public class Test {

    private Admin loggedInAdmin;
    private String selectedCategoryName;

    @FXML
    private ScrollPane productsScrollPane;

    @FXML
    private Label messageLabel;

    @FXML
    private AnchorPane cartPanel;

    @FXML
    private Button cartButton;

    @FXML
    private Button closeCartButton;

    @FXML
    private VBox cartVBox;

    private final int PANEL_WIDTH = 500;
    private final Duration ANIMATION_DURATION = Duration.millis(500);

    public void initialize(Admin admin) {
        loggedInAdmin = admin;

        cartPanel.setTranslateX(PANEL_WIDTH);

        cartButton.setOnMouseClicked(mouseEvent -> showCart());
        closeCartButton.setOnMouseClicked(mouseEvent -> hideCart());
    }

    @FXML
    public void showCart() {
        TranslateTransition slideIn = new TranslateTransition(Duration.millis(600), cartPanel);
        slideIn.setToX(-300);
        slideIn.play();
    }

    @FXML
    public void hideCart() {
        TranslateTransition slideOut = new TranslateTransition(Duration.millis(600), cartPanel);
        slideOut.setToX(500);
        slideOut.play();
    }





}
