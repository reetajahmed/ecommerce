package com.example.oop_v3.controllers;

import com.example.oop_v3.admin.Admin;
import com.example.oop_v3.database.Database;
import com.example.oop_v3.customer.Customer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button LoginButton;

    @FXML
    private Button signUpButton;
    @FXML
    private Button gobackButton;

    @FXML
    private Label messageLabel;

    @FXML
    public void handleGoBack(ActionEvent event) {
        try {
            // Load the home page FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/HomePage.fxml"));
            Parent homeScene = loader.load();

            // Get the current stage (window) and change the scene
            Stage stage = (Stage) gobackButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(homeScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.setTitle("Back Page");


            // Show the new scene (home page)
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            // Show error if something goes wrong
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("An error occurred while going back. Please try again.");
            alert.showAndWait();
        }
    }



    // Show an alert with a given title and message
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void onLoginButtonClick() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            // Show an alert for empty fields
            showAlert("Login Error", "Username or password cannot be empty!");
            return;
        }

        // Check if the admin credentials are valid
        Admin admin = Database.getInstance().findAdminByUsernameAndPassword(username, password);
        if (admin != null) {
            // Show a success alert for admin login
            showAlert("Login Successful", "Welcome, " + admin.getRole() + "!");
            // Navigate to the admin dashboard
            navigateToDashboard();
            return; // Exit the method after successful admin login
        }

        // Check if the customer credentials are valid
        Customer customer = Database.getInstance().findCustomerByUsernameAndPassword(username, password);
        if (customer != null) {
            // Show a success alert for customer login
            showAlert("Login Successful", "Welcome, " + username + "!");
            // Navigate to the customer dashboard
            navigateToDashboard(customer);
        } else {
            // Show an alert for invalid credentials
            showAlert("Login Error", "Invalid username or password.");
        }
    }


    // Sign-Up button action
    @FXML
    public void onSignUpButtonClick() {
        try
        {
            // Load the Signup FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/Signup.fxml"));
            Parent signupPage = loader.load();

            // Get the current stage (window) and set the new scene
            Stage stage = (Stage) signUpButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene
            Scene scene = new Scene(signupPage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the fxml file is not found or there's an error loading it
        }
    }

    // Navigate to the main dashboard after successful login
    // Navigate to the main dashboard after successful login
    private void navigateToDashboard(Customer customer)
    {
        System.out.println("Navigating to the dashboard...");
        try {

            // Load the logged-in home page FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/loggedinHomePage.fxml"));
            Parent loggedinHomePage = loader.load();

            // Get the controller of the loaded FXML
            LoggedinHomePageController controller = loader.getController();

            // Pass the logged-in customer to the controller
            controller.initialize(customer);

            // Get the current stage (window) from any existing UI element
            Stage stage = (Stage) LoginButton.getScene().getWindow();

            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(loggedinHomePage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            // Show the updated stage
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the FXML file is not found or there's an error loading it
        }
    }

private void navigateToDashboard()
    {
        System.out.println("Navigating to the dashboard...");
        try {

            // Load the logged-in home page FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/AdminCategories/adminpage.fxml"));
            Parent Test = loader.load();


            // Get the current stage (window) from any existing UI element
            Stage stage = (Stage) LoginButton.getScene().getWindow();

            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(Test, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            // Show the updated stage
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the FXML file is not found or there's an error loading it
        }
    }


}