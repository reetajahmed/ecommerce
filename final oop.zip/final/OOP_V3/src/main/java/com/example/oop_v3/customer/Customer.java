package com.example.oop_v3.customer;
import com.example.oop_v3.database.Database;
import com.example.oop_v3.person.Person;
import com.example.oop_v3.category.Category;
import com.example.oop_v3.cart.Cart;
import java.util.List;
import java.util.Scanner;

public class Customer extends Person
{

    private double balance;
    private String[] interests;
    private Cart cart;

    public Customer(String username, String password, String dateOfBirth, String address, Gender gender, double balance, String[] interests) {
        super(username,password, dateOfBirth, address, gender);
        this.balance = balance;
        this.interests = interests;
        Database.getInstance().addCustomer(this);
        this.cart = new Cart(); // Each customer gets their own cart


    }
    public Customer(String username, String password, String dateOfBirth, String address, Gender gender, double balance) {
        super(username,password, dateOfBirth, address, gender);
        this.balance = balance;
        Database.getInstance().addCustomer(this);
        this.cart = new Cart(); // Each customer gets their own cart

    }

    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }
    public String[] getInterests() {
        return interests;
    }
    public void setInterests(String[] interests) {
        this.interests = interests;
    }
    public Cart getCart() {return cart;}



    @Override
    public void displayInfo() {
        System.out.println("Customer Information:");
        System.out.println("Username: " + getUsername());
        System.out.println("Date of Birth: " + getDateOfBirth());
        System.out.println("Address: " + getAddress());
        System.out.println("Gender: " + getGender());
        System.out.println("Balance: " + getBalance() + " EGP");

        System.out.print("Interests: ");
        if (interests != null && interests.length > 0) {
            for (int i = 0; i < interests.length; i++) {
                System.out.print(interests[i]);
                if (i < interests.length - 1) {
                    System.out.print(", ");
                }
            }
        } else {
            System.out.print("No interests listed.");
        }
        System.out.println();
    }
    public static void addCustomer(Customer customer) {
        Database.getInstance().addCustomer(customer);
    }

    public void chooseInterests() {
        Scanner scanner = new Scanner(System.in);
        List<Category> categories = Database.getInstance().getCategories();
        Category.displayCategories(categories);

        System.out.println("Enter the indices of categories you are interested in, separated by commas :");
        String input = scanner.nextLine();

        try {

            String[] indices = input.split(",");
            String[] selectedInterests = new String[indices.length];

            for (int i = 0; i < indices.length; i++) {
                int categoryIndex = Integer.parseInt(indices[i].trim()) - 1;

                if (categoryIndex < 0 || categoryIndex >= categories.size()) {
                    System.out.println("Invalid index: " + (categoryIndex + 1));
                    return;
                }

                selectedInterests[i] = categories.get(categoryIndex).getCategoryName();
            }
            setInterests(selectedInterests);
            System.out.println("Your interests have been updated: " + String.join(", ", selectedInterests));
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter valid indices.");
        }
    }
    public Customer getCustomerByUsername(String username) {
        for (Customer customer : Database.getInstance().getCustomers()) {
            if (customer.getUsername().equals(username)) {
                return customer;
            }
        }
        return null;
    }

}
