package com.example.oop_v3.controllers;

import com.example.oop_v3.cart.Cart;
import com.example.oop_v3.customer.Customer;
import com.example.oop_v3.database.Database;
import com.example.oop_v3.product.Product;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.List;

public class ProductPageLoggedinController {

    private Customer loggedInCustomer;
    private String selectedCategoryName;

    @FXML
    private ScrollPane productsScrollPane;

    @FXML
    private Label messageLabel;

    @FXML
    private AnchorPane cartPanel;

    @FXML
    private Button cartButton;

    @FXML
    private Button closeCartButton;

    @FXML
    private VBox cartVBox;

    @FXML
    private Button backButton;

    @FXML
    private Button cartCheckoutButton;

    private final int PANEL_WIDTH = 500;
    private final Duration ANIMATION_DURATION = Duration.millis(500);

    public void initialize(Customer customer, String categoryName) {
        loggedInCustomer = customer;
        selectedCategoryName = categoryName;
        loadProducts();
        refreshCartView();

        cartPanel.setTranslateX(PANEL_WIDTH);

        cartButton.setOnMouseClicked(mouseEvent -> showCart());
        closeCartButton.setOnMouseClicked(mouseEvent -> hideCart());
    }

    @FXML
    private void handleBack() {
        try {


                // Load the logged-in home page FXML file
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/loggedinHomePage.fxml"));
                Parent loggedinHomePage = loader.load();

                // Get the controller of the loaded FXML
                LoggedinHomePageController controller = loader.getController();

                // Pass the logged-in customer to the controller
                controller.initialize(loggedInCustomer);

                // Get the current stage (window) from any existing UI element
                Stage stage = (Stage) backButton.getScene().getWindow();

                // Preserve current window size
                double currentWidth = stage.getWidth();
                double currentHeight = stage.getHeight();

                // Set the new scene with the preserved size
                Scene scene = new Scene(loggedinHomePage, currentWidth, currentHeight);
                stage.setScene(scene);

                // Explicitly set the stage size
                stage.setWidth(currentWidth);
                stage.setHeight(currentHeight);

                // Show the updated stage
                stage.show();
            } catch (IOException e) {
                e.printStackTrace(); // Handle exception if the FXML file is not found or there's an error loading it
            }
    }

    @FXML
    private void navigateToCheckout() {

        System.out.println("Checkout button clicked");
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/Checkout/Checkout.fxml"));
            Parent checkoutPage = loader.load();

            CheckoutPageController controller = loader.getController();
            controller.initialize(loggedInCustomer);

            Stage stage = (Stage) cartCheckoutButton.getScene().getWindow();

            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();


            Scene scene = new Scene(checkoutPage, currentWidth, currentHeight);
            stage.setScene(scene);


            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.setTitle("Checkout Page");

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load Checkout page.");
        }
    }

    @FXML
    public void showCart() {
        TranslateTransition slideIn = new TranslateTransition(Duration.millis(600), cartPanel);
        slideIn.setToX(-300);
        slideIn.play();
    }

    @FXML
    public void hideCart() {
        TranslateTransition slideOut = new TranslateTransition(Duration.millis(600), cartPanel);
        slideOut.setToX(500);
        slideOut.play();
    }

    private void loadProducts() {
        // Ensure ScrollPane has a container for products
        FlowPane productsFlowPane = new FlowPane();
        productsFlowPane.setHgap(20); // Horizontal gap between products
        productsFlowPane.setVgap(20); // Vertical gap between rows
        productsScrollPane.setContent(productsFlowPane);



        Database database = Database.getInstance();
        List<Product> products = database.findCategoryByName(selectedCategoryName).getProducts();

        if (products == null || products.isEmpty()) {
            if (messageLabel != null) {
                messageLabel.setText("No products available in this category.");
            }
            return;
        }

        for (Product product : products) {
            VBox productBox = createProductBox(product);
            productsFlowPane.getChildren().add(productBox);
        }
    }

    private VBox createProductBox(Product product) {
        VBox productBox = new VBox();
        productBox.setSpacing(10);
        productBox.setAlignment(javafx.geometry.Pos.CENTER);

        double boxWidth = 412.5;
        double boxHeight = 275;
        productBox.setPrefSize(boxWidth, boxHeight);

        Rectangle clip = new Rectangle(boxWidth, boxHeight);
        clip.setArcWidth(60);
        clip.setArcHeight(60);
        productBox.setClip(clip);

        if (product.getImagePath() != null && !product.getImagePath().isEmpty()) {
            productBox.setStyle("-fx-background-image: url('" + product.getImagePath() + "');"
                    + "-fx-background-size: cover; -fx-background-radius: 30; -fx-background-insets: 0;"
                    + "-fx-border-color: #d8bfd8; -fx-border-width: 2; -fx-border-radius: 30; -fx-padding: 15;");
        } else {
            productBox.setStyle("-fx-background-color: rgba(138, 43, 226, 0.8);"
                    + "-fx-border-color: #d8bfd8; -fx-border-width: 2; -fx-border-radius: 30; -fx-background-radius: 30;"
                    + "-fx-padding: 15;");
        }

        Text productName = new Text(product.getName());
        productName.setStyle("-fx-font-size: 15px; -fx-font-weight: 900; -fx-fill: rgb(75, 0, 135); -fx-font-family: 'Lucida Calligraphy';");

        Text productPrice = new Text("Price: " + product.getPrice());
        productPrice.setStyle("-fx-font-size: 12px; -fx-fill: rgb(75, 0, 135);");

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setStyle("-fx-background-color: #4b0082; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10;");
        addToCartButton.setOnAction(e -> {
            loggedInCustomer.getCart().addItem(product, 1);
            refreshCartView();
        });

        productBox.getChildren().addAll(productName, productPrice, addToCartButton);
        return productBox;
    }

    private void refreshCartView() {
        if (cartVBox == null) {
            return;
        }
        cartVBox.getChildren().clear();

        Cart cart = loggedInCustomer.getCart();
        List<Product> products = cart.getProducts();
        List<Integer> quantities = cart.getQuantities();

        if (products.isEmpty()) {
            cartVBox.setAlignment(javafx.geometry.Pos.CENTER);
            Label emptyCartLabel = new Label("Your cart is empty.");
            emptyCartLabel.setStyle("-fx-font-size: 24px; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-family: 'Lucida Calligraphy';");
            cartVBox.getChildren().add(emptyCartLabel);
        } else {
            cartVBox.setAlignment(javafx.geometry.Pos.TOP_LEFT);
            for (int i = 0; i < products.size(); i++) {
                Product product = products.get(i);
                int quantity = quantities.get(i);

                HBox productBox = new HBox(15);
                productBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
                productBox.setStyle("-fx-padding: 10; -fx-background-color: rgba(255, 255, 255, 0.1); "
                        + "-fx-border-radius: 10; -fx-background-radius: 10;");

                ImageView productImage = new ImageView(new Image(product.getImagePath()));
                productImage.setFitWidth(60);
                productImage.setFitHeight(60);

                Label productName = new Label(product.getName());
                productName.setStyle("-fx-font-size: 16px; -fx-text-fill: white; -fx-font-weight: bold;");
                productName.setWrapText(true);
                productName.setMaxWidth(150);

                HBox quantityBox = new HBox(5);
                quantityBox.setAlignment(javafx.geometry.Pos.CENTER);

                Button minusButton = new Button("-");
                minusButton.setStyle("-fx-background-color: white;");
                minusButton.setPrefSize(30, 30);

                TextField quantityField = new TextField(String.valueOf(quantity));
                quantityField.setPrefSize(40, 32);

                Button plusButton = new Button("+");
                plusButton.setPrefSize(30, 30);
                plusButton.setStyle("-fx-background-color: white;");

                minusButton.setOnAction(e -> {
                    int currentQuantity = Integer.parseInt(quantityField.getText());
                    if (currentQuantity > 1) {
                        quantityField.setText(String.valueOf(currentQuantity - 1));
                        cart.addItem(product, -1);
                        refreshCartView();
                    }
                });

                plusButton.setOnAction(e -> {
                    quantityField.setText(String.valueOf(Integer.parseInt(quantityField.getText()) + 1));
                    cart.addItem(product, 1);
                    refreshCartView();
                });

                quantityBox.getChildren().addAll(minusButton, quantityField, plusButton);

                Button removeButton = new Button("delete");
                removeButton.setPrefSize(60, 30);
                removeButton.setStyle("-fx-background-color: white;");
                removeButton.setOnAction(e -> {
                    cart.removeItem(product);
                    refreshCartView();
                });

                HBox buttonsBox = new HBox(10);
                buttonsBox.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);
                buttonsBox.getChildren().addAll(quantityBox, removeButton);

                productBox.getChildren().addAll(productImage, productName, buttonsBox);
                cartVBox.getChildren().add(productBox);
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
