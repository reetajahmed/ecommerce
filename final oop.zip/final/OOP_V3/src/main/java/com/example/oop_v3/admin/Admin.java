package com.example.oop_v3.admin;
import com.example.oop_v3.person.Person;
import com.example.oop_v3.database.Database;
import com.example.oop_v3.product.Product;
import com.example.oop_v3.customer.Customer;
import com.example.oop_v3.productNotFoundException.ProductNotFoundException;


import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Admin extends Person
{
    private String role;
    private int workingHours;

    public Admin(String username, String password, String dateOfBirth, String address, Gender gender, String role, int workingHours) {
        super(username, password, dateOfBirth, address, gender);
        this.role = role;
        this.workingHours = workingHours;

    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(int workingHours) {
        if (workingHours < 0) {
            throw new IllegalArgumentException("Working hours cannot be negative.");
        }
        this.workingHours = workingHours;
    }

    @Override
    public void displayInfo() {
        System.out.println("Admin Info: " + getUsername() + ", Role: " + role + ", Working Hours: " + workingHours);
    }


    public void addProduct(Product product, String categoryName) {
        try {
            if (product == null || categoryName == null || categoryName.isEmpty()) {
                throw new IllegalArgumentException("Product or category name cannot be null or empty.");
            }
            Database.getInstance().addProduct(product, categoryName);
            System.out.println(product.getName() + " is added to the " + categoryName + " category.");
        } catch (Exception e) {
            System.out.println("Error while adding product: " + e.getMessage());
        }
    }


    public void removeProduct(int productId) throws ProductNotFoundException {
        Product product = Database.getInstance().findProductById(productId);
        if (product == null) {
            throw new ProductNotFoundException("Product with ID " + productId + " not found.");
        }
        Database.getInstance().getProducts().remove(product);
        System.out.println(product.getName() + " has been removed from the " + product.getCategory() + " category.");
    }


    public void editProduct(int productId) {
        // Get the list of products from the database
        List<Product> products = Database.getInstance().getProducts();

        // Find the product by ID
        Product productToEdit = null;
        for (Product product : products) {
            if (product.getId() == productId) {
                productToEdit = product;
                break;
            }
        }

        if (productToEdit == null) {
            System.out.println("Product with ID " + productId + " not found.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        int option = 0;
        System.out.println("Menu:");
        System.out.println("[1]: Edit Product Name");
        System.out.println("[2]: Edit Product Price");
        System.out.println("[3]: Edit Product Stock");
        System.out.print("Choose an option: ");

        try {
            option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character


            switch (option) {
                case 1:
                    System.out.print("Enter new product name: ");
                    String newName = scanner.nextLine();
                    if (!newName.trim().isEmpty()) {
                        productToEdit.setName(newName);
                        System.out.println("Product name updated successfully.");
                    } else {
                        System.out.println("Invalid name. No changes made.");
                    }
                    break;
                case 2:
                    System.out.print("Enter new product price: ");
                    double newPrice = scanner.nextDouble();
                    if (newPrice > 0) {
                        productToEdit.setPrice(newPrice);
                        System.out.println("Product price updated successfully.");
                    } else {
                        System.out.println("Invalid price. No changes made.");
                    }
                    break;
                case 3:
                    System.out.print("Enter new product stock: ");
                    int newStock = scanner.nextInt();
                    if (newStock >= 0) {
                        productToEdit.setStock(newStock);
                        System.out.println("Product stock updated successfully.");
                    } else {
                        System.out.println("Invalid stock value. No changes made.");
                    }
                    break;
                default:
                    System.out.println("Invalid option. No changes made.");
                    break;
            }
        } catch(InputMismatchException e){
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine(); // Clear the invalid input
        }
        catch(Exception e)
        {
            System.out.println("An unexpected error occurred: " + e.getMessage());

        }

    }



    public void showAllUsers() {
        try {
            List<Customer> customers = Database.getInstance().getCustomers();

            if (customers == null || customers.isEmpty()) {
                System.out.println("No customers found.");
                return;
            }

            System.out.println("All Registered Customers:");
            for (Customer customer : customers) {
                System.out.println("Username: " + customer.getUsername());
                System.out.println("Date of Birth: " + customer.getDateOfBirth());
                System.out.println("Address: " + customer.getAddress());
                System.out.println("Gender: " + customer.getGender());
                System.out.println("Balance: " + customer.getBalance() + " EGP");

                String[] interests = customer.getInterests();
                System.out.print("Interests: ");
                if (interests != null && interests.length > 0) {
                    for (int i = 0; i < interests.length; i++) {
                        System.out.print(interests[i]);
                        if (i < interests.length - 1) {
                            System.out.print(", ");
                        }
                    }
                    System.out.println();
                } else {
                    System.out.println("No interests listed.");
                }

                System.out.println("---------------------------------------");
            }
        } catch(Exception e){
            System.out.println("Error while displaying users: " + e.getMessage());
        }
    }

}