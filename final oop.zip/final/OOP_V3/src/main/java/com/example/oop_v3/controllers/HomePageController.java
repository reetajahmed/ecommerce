package com.example.oop_v3.controllers;

import com.example.oop_v3.category.Category;
import com.example.oop_v3.database.Database;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.shape.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class HomePageController {

    @FXML
    private Button loginButton;

    @FXML
    private Button registerButton;

    @FXML
    private Label messageLabel;

    @FXML
    private ScrollPane categoriesScrollPane;

    @FXML
    private HBox categoriesHBox;


    // Initialize the controller after the FXML is loaded
    public void initialize() {
        System.out.println("Controller initialized");

        if (categoriesHBox == null) {
            System.out.println("categoriesHBox is null!");
        } else {
            System.out.println("categoriesHBox initialized successfully.");
        }
        loadCategories();
    }



    // Handle the Login button action
    @FXML
    private void handleLogin()
    {
        try {
            // Load the Login FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/login.fxml"));
            Parent loginPage = loader.load(); // Use Parent to avoid casting issues

            // Get the current stage (window) and set the new scene
            Stage stage = (Stage) loginButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene
            Scene scene = new Scene(loginPage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the FXML file is not found or there's an error loading it
        }
    }

    // Handle the Register button action
    @FXML
    private void handleRegister() {
        try {
            // Load the Signup FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/Signup.fxml"));
            Parent signupPage = loader.load();

            // Get the current stage (window) and set the new scene
            Stage stage = (Stage) registerButton.getScene().getWindow();

            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene
            Scene scene = new Scene(signupPage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the fxml file is not found or there's an error loading it
        }
    }

    private void navigateToCategory(Category category) {
        System.out.println("Navigating to the Product Page...");

        try {
            // Correct the path to the ProductPage.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/ProductPage/ProductPage.fxml"));
            Parent productPage = loader.load();

            // Get the controller of the loaded FXML
            ProductPageController controller = loader.getController();

            // Pass the category name to the controller
            controller.initialize(category.getCategoryName());

            // Get the current stage (the window where the current scene is displayed)
            Stage stage = (Stage) categoriesHBox.getScene().getWindow();

            // Preserve the current size of the window
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(productPage, currentWidth, currentHeight);
            stage.setScene(scene);

            // Explicitly set the stage size (optional, but good practice)
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            // Show the updated stage with the new scene
            stage.show();

        } catch (IOException e) {
            e.printStackTrace(); // Handle exception if the FXML file is not found or there's an error loading it
        }
    }



    private void loadCategories() {
        Database database = Database.getInstance();
        List<Category> categories = database.getCategories();

        System.out.println("Categories loaded: " + (categories != null ? categories.size() : "null"));

        if (categories == null || categories.isEmpty()) {
            System.out.println("No categories available.");
            if (messageLabel != null) {
                messageLabel.setText("No categories available.");
            }
            return;
        }

        for (Category category : categories) {
            System.out.println("Category: " + category.getCategoryName());
            VBox categoryBox = createCategoryBox(category);

            // Add a click handler to each category box
            categoryBox.setOnMouseClicked(event -> {
                System.out.println("Category clicked: " + category.getCategoryName()); // Debugging
                navigateToCategory(category);
            });

            categoriesHBox.getChildren().add(categoryBox); // Add to the HBox
        }
    }



    private VBox createCategoryBox(Category category) {
        VBox categoryBox = new VBox();
        categoryBox.setSpacing(10);
        categoryBox.setAlignment(javafx.geometry.Pos.CENTER);

        double boxWidth = 400; // Width of the VBox
        double boxHeight = 200; // Height of the VBox
        categoryBox.setPrefSize(boxWidth, boxHeight);

        // Clip the VBox to enforce rounded corners
        Rectangle clip = new Rectangle(boxWidth, boxHeight);
        clip.setArcWidth(20); // Rounded corners
        clip.setArcHeight(20);
        categoryBox.setClip(clip);


        // Add Background Image or Color
        String bgImageUrl = category.getBgImageUrl();
        if (bgImageUrl != null && !bgImageUrl.isEmpty()) {
            categoryBox.setStyle("-fx-background-image: url('" + bgImageUrl + "');"
                    + "-fx-background-size: cover;" // Ensure the image fills the box
                    + "-fx-background-position: center;"
                    + "-fx-background-radius: 40;" // Match the clip
                    + "-fx-border-color: #d8bfd8; -fx-border-width: 2;" // Add a border
                    + "-fx-border-radius: 5;"); // Rounded corners for the border
        } else {
            categoryBox.setStyle("-fx-background-color: rgba(138, 43, 226, 0.8);"
                    + "-fx-border-color: #d8bfd8; -fx-border-width: 2;"
                    + "-fx-border-radius: 20;");
        }

        // Add Category Name and Description
        Text categoryName = new Text(category.getCategoryName());
        categoryName.setStyle("-fx-font-size: 25px; -fx-font-weight: 900; -fx-fill: rgb(75, 0, 135); -fx-font-family: 'Lucida Calligraphy';");

        Text categoryDescription = new Text(category.getDescription());
        categoryDescription.setStyle("-fx-font-size: 14px; -fx-fill: rgb(75, 0, 135);");

        // Add the text components to the VBox
        categoryBox.getChildren().addAll(categoryName, categoryDescription);

        return categoryBox;
    }


}
