package com.example.oop_v3.controllers;

import com.example.oop_v3.cart.Cart;
import com.example.oop_v3.customer.Customer;
import com.example.oop_v3.database.Database;
import com.example.oop_v3.product.Product;
import com.example.oop_v3.category.Category;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;
import java.util.List;

public class LoggedinHomePageController
{

    private Customer loggedInCustomer;

    @FXML
    private ScrollPane categoriesScrollPane;

    @FXML
    private HBox categoriesHBox;

    @FXML
    private Label messageLabel;

    @FXML
    private AnchorPane cartPanel;

    @FXML
    private Button cartButton;

    @FXML
    private Button closeCartButton;

    @FXML
    private Button logoutButton;

    @FXML
    private Button cartCheckoutButton;


    @FXML
    private VBox cartVBox;  // Change from ListView to VBox for custom layout

    private final int PANEL_WIDTH = 500; // Width of the side panel
    private final Duration ANIMATION_DURATION = Duration.millis(500); // Animation duration

    public void initialize(Customer customer) {
        System.out.println("Controller initialized");

        if (categoriesHBox == null) {
            System.out.println("categoriesHBox is null!");
        } else {
            System.out.println("categoriesHBox initialized successfully.");
        }
        loadCategories();
        loggedInCustomer = customer;

        refreshCartView();


        // Ensure the cart panel is initially off-screen
        cartPanel.setTranslateX(PANEL_WIDTH);

        // Attach event handlers for the buttons
        cartButton.setOnMouseClicked(mouseEvent -> showCart());
        closeCartButton.setOnMouseClicked(mouseEvent -> hideCart());
    }
public void emptycart(Customer customer) {
        System.out.println("Controller initialized");

    // Ensure the cart is cleared for the logged-in customer
    if (customer != null && customer.getCart() != null) {
        customer.getCart().clear(); // Assuming Cart has a clear method
        System.out.println("Cart emptied successfully.");
    } else {
        System.out.println("Failed to empty the cart: Customer or Cart is null.");
    }

        if (categoriesHBox == null) {
            System.out.println("categoriesHBox is null!");
        } else {
            System.out.println("categoriesHBox initialized successfully.");
        }
        loadCategories();
        loggedInCustomer = customer;

        refreshCartView();


        // Ensure the cart panel is initially off-screen
        cartPanel.setTranslateX(PANEL_WIDTH);

        // Attach event handlers for the buttons
        cartButton.setOnMouseClicked(mouseEvent -> showCart());
        closeCartButton.setOnMouseClicked(mouseEvent -> hideCart());
    }

    @FXML
    private void navigateToCheckout() {

        System.out.println("Checkout button clicked");
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/Checkout/Checkout.fxml"));
            Parent checkoutPage = loader.load();

            CheckoutPageController controller = loader.getController();
            controller.initialize(loggedInCustomer);

            Stage stage = (Stage) cartCheckoutButton.getScene().getWindow();

            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();


            Scene scene = new Scene(checkoutPage, currentWidth, currentHeight);
            stage.setScene(scene);


            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.setTitle("Checkout Page");

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load Checkout page.");
        }
    }


    @FXML
    public void showCart() {
        TranslateTransition slideIn = new TranslateTransition(Duration.millis(600), cartPanel);
        slideIn.setToX(-300); // Slide into view
        slideIn.play();
    }

    @FXML
    public void hideCart() {
        TranslateTransition slideOut = new TranslateTransition(Duration.millis(600), cartPanel);
        slideOut.setToX(500); // Slide out of view
        slideOut.play();
    }



    private void navigateToCategory(Category category) {
        // Assuming you have a way to load the Test.fxml and initialize the controller.
        try {
            // Load the FXML for the Test screen
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/ProductPage/ProductPageLoggedin.fxml"));
            Parent root = loader.load();

            // Get the controller and initialize it with the logged-in customer and selected category
            ProductPageLoggedinController controller = loader.getController();
            controller.initialize(loggedInCustomer, category.getCategoryName());

            // Get the current scene and set the new screen
            Scene currentScene = cartButton.getScene();
            currentScene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception if loading FXML fails
        }
    }

    public void logoutHandle() {
        // Assuming you have a way to load the Test.fxml and initialize the controller.
        try {
            // Load the FXML for the Test screen
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/HomePage.fxml"));
            Parent root = loader.load();

            // Get the current scene and set the new screen
            Scene currentScene = logoutButton.getScene();
            currentScene.setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception if loading FXML fails
        }
    }


    private void loadCategories() {
        Database database = Database.getInstance();
        List<Category> categories = database.getCategories();

        System.out.println("Categories loaded: " + (categories != null ? categories.size() : "null"));

        if (categories == null || categories.isEmpty()) {
            System.out.println("No categories available.");
            if (messageLabel != null) {
                messageLabel.setText("No categories available.");
            }
            return;
        }

        for (Category category : categories) {
            System.out.println("Category: " + category.getCategoryName());
            VBox categoryBox = createCategoryBox(category);

            // Add a click handler to each category box
            categoryBox.setOnMouseClicked(event -> navigateToCategory(category));

            categoriesHBox.getChildren().add(categoryBox); // Add to the HBox
        }
    }


    private VBox createCategoryBox(Category category) {
        VBox categoryBox = new VBox();
        categoryBox.setSpacing(10);
        categoryBox.setAlignment(javafx.geometry.Pos.CENTER);

        double boxWidth = 400; // Width of the VBox
        double boxHeight = 200; // Height of the VBox
        categoryBox.setPrefSize(boxWidth, boxHeight);

        // Clip the VBox to enforce rounded corners
        Rectangle clip = new Rectangle(boxWidth, boxHeight);
        clip.setArcWidth(20); // Rounded corners
        clip.setArcHeight(20);
        categoryBox.setClip(clip);


        // Add Background Image or Color
        String bgImageUrl = category.getBgImageUrl();
        if (bgImageUrl != null && !bgImageUrl.isEmpty()) {
            categoryBox.setStyle("-fx-background-image: url('" + bgImageUrl + "');"
                    + "-fx-background-size: cover;" // Ensure the image fills the box
                    + "-fx-background-position: center;"
                    + "-fx-background-radius: 40;" // Match the clip
                    + "-fx-border-color: #d8bfd8; -fx-border-width: 2;" // Add a border
                    + "-fx-border-radius: 5;"); // Rounded corners for the border
        } else {
            categoryBox.setStyle("-fx-background-color: rgba(138, 43, 226, 0.8);"
                    + "-fx-border-color: #d8bfd8; -fx-border-width: 2;"
                    + "-fx-border-radius: 20;");
        }

        // Add Category Name and Description
        Text categoryName = new Text(category.getCategoryName());
        categoryName.setStyle("-fx-font-size: 25px; -fx-font-weight: 900; -fx-fill: rgb(75, 0, 135); -fx-font-family: 'Lucida Calligraphy';");

        Text categoryDescription = new Text(category.getDescription());
        categoryDescription.setStyle("-fx-font-size: 14px; -fx-fill: rgb(75, 0, 135);");

        // Add the text components to the VBox
        categoryBox.getChildren().addAll(categoryName, categoryDescription);

        return categoryBox;
    }

    private void refreshCartView() {
        if (cartVBox == null) {
            return;  // Early exit if cartVBox is not initialized
        }
        cartVBox.getChildren().clear(); // Clear previous items

        Cart cart = loggedInCustomer.getCart();
        List<Product> products = cart.getProducts();
        List<Integer> quantities = cart.getQuantities();

        if (products.isEmpty()) {
            // Center the message and style it
            cartVBox.setAlignment(javafx.geometry.Pos.CENTER); // Center the content
            Label emptyCartLabel = new Label("Your cart is empty.");
            emptyCartLabel.setStyle("-fx-font-size: 24px; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-family: 'Lucida Calligraphy';");
            cartVBox.getChildren().add(emptyCartLabel);
        } else {
            cartVBox.setAlignment(javafx.geometry.Pos.TOP_LEFT); // Reset alignment for non-empty cart
            for (int i = 0; i < products.size(); i++) {
                Product product = products.get(i);
                int quantity = quantities.get(i);

                HBox productBox = new HBox(15); // Increase spacing between items
                productBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
                productBox.setStyle("-fx-padding: 10; -fx-background-color: rgba(255, 255, 255, 0.1); "
                        + "-fx-border-radius: 10; -fx-background-radius: 10;");

                // Product Image
                ImageView productImage = new ImageView(new Image(product.getImagePath()));
                productImage.setFitWidth(60); // Slightly larger image size
                productImage.setFitHeight(60);

                // Product Name (with text wrapping)
                Label productName = new Label(product.getName());
                productName.setStyle("-fx-font-size: 16px; -fx-text-fill: white; -fx-font-weight: bold;");
                productName.setWrapText(true); // Enable wrapping
                productName.setMaxWidth(150); // Limit width to allow space for buttons

                // Quantity Controls
                HBox quantityBox = new HBox(5); // Small spacing between controls
                quantityBox.setAlignment(javafx.geometry.Pos.CENTER);

                Button minusButton = new Button("-");
                minusButton.setStyle("-fx-background-color: white;");
                minusButton.setPrefSize(30, 30);

                TextField quantityField = new TextField(String.valueOf(quantity));
                quantityField.setPrefSize(40, 32);

                Button plusButton = new Button("+");
                plusButton.setPrefSize(30, 30);
                plusButton.setStyle("-fx-background-color: white;");

                minusButton.setOnAction(e -> {
                    int currentQuantity = Integer.parseInt(quantityField.getText());
                    if (currentQuantity > 1) {
                        quantityField.setText(String.valueOf(currentQuantity - 1));
                        cart.addItem(product, -1);
                        refreshCartView();
                    }
                });

                plusButton.setOnAction(e -> {
                    quantityField.setText(String.valueOf(Integer.parseInt(quantityField.getText()) + 1));
                    cart.addItem(product, 1);
                    refreshCartView();
                });

                quantityBox.getChildren().addAll(minusButton, quantityField, plusButton);

                // Remove Button
                Button removeButton = new Button("delete");
                removeButton.setPrefSize(60, 30);
                removeButton.setStyle("-fx-background-color: white;");
                removeButton.setOnAction(e -> {
                    cart.removeItem(product);
                    refreshCartView();
                });

                // Align all buttons (quantity controls and remove button) together
                HBox buttonsBox = new HBox(10);
                buttonsBox.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);
                buttonsBox.getChildren().addAll(quantityBox, removeButton);

                // Add all elements to the productBox
                productBox.getChildren().addAll(productImage, productName, buttonsBox);
                cartVBox.getChildren().add(productBox);
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
