package com.example.oop_v3.creditCard;
import com.example.oop_v3.payments.Payments;


public class CreditCard implements Payments {
    private String cardNumber;
    private String cardHolderName;
    private String expiryDate;

    public CreditCard(String cardNumber, String cardHolderName, String expiryDate) {
        if (!isValidCardNumber(cardNumber)) {
            throw new IllegalArgumentException("Invalid card number.");
        }
        this.cardNumber = cardNumber;

        setCardHolderName(cardHolderName);

        setExpiryDate(expiryDate);
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        if (!isValidCardNumber(cardNumber)) {
            throw new IllegalArgumentException("Invalid card number.");
        }
        this.cardNumber = cardNumber;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        if (cardHolderName == null || cardHolderName.trim().isEmpty()) {
            throw new IllegalArgumentException("Cardholder name cannot be empty.");
        }
        if(!cardHolderName.matches("[a-zA-Z\\s]+")){
            throw new IllegalArgumentException("Cardholder name must only contain letters and spaces.");
        }
        this.cardHolderName = cardHolderName;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        if (expiryDate == null || expiryDate.length() != 5) {
            throw new IllegalArgumentException("Expiry date must be in the format MM/YY.");
        }
        String[] parts = expiryDate.split("/");

        if (parts.length != 2) {
            throw new IllegalArgumentException("Expiry date must be in the format MM/YY.");
        }

        String month = parts[0];
        String year = parts[1];

        if (Integer.parseInt(month) < 1 || Integer.parseInt(month) > 12) {
            throw new IllegalArgumentException("Month must be between 01 and 12.");
        }

        if (year.length() != 2 || !year.matches("\\d{2}")) {
            throw new IllegalArgumentException("Year must be a two-digit number.");
        }

        this.expiryDate = expiryDate;
    }

    @Override
    public boolean paymentCompleted(double amount) {
        System.out.println("Processing Credit Card Payment for amount: " + amount + " EGP");
        return true;
    }

    private boolean isValidCardNumber(String cardNumber) {
        return cardNumber != null && cardNumber.matches("\\d{16}");
    }

    @Override
    public void displayDetails() {
        System.out.println("Payment Method: Credit Card");
        System.out.println("Card Holder: " + cardHolderName);
        System.out.println("Card Number: **** **** **** " + cardNumber.substring(cardNumber.length() - 4));
        System.out.println("Expiry Date: " + expiryDate);
    }

    @Override
    public String getMethodName() {
        return "Credit Card";
    }
}

