package com.example.oop_v3.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import com.example.oop_v3.database.Database;
import com.example.oop_v3.category.Category;
import com.example.oop_v3.product.Product;
import javafx.event.ActionEvent;


import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.Button;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Alert.AlertType;

import java.io.IOException;

public class AdminPageController {

    @FXML
    private Button productButton;

    @FXML
    private Button ordersButton;

    @FXML
    private Button usersButton;

    @FXML
    private Button logoutButton;

    @FXML
    private Button removeButton;

    @FXML
    private Button addButton;

    @FXML
    private void handleAddProduct() {
        try {
            // Load the Add Product page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/AdminCategories/AddProduct.fxml"));
            Parent addProductScene = loader.load();

            // Get the current stage and set the new scene
            Stage stage = (Stage) addButton.getScene().getWindow();

            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(addProductScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);
            stage.setTitle("Add Product");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Show an error alert if loading fails
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to load the Add Product page.");
            alert.show();
        }
    }

    @FXML
    private void handleOrders(ActionEvent event) {
        try {
            // Load the Order page (FXML with OrderController)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/AdminCategories/Orders.fxml"));
            Parent orderScene = loader.load();

            // Get the current stage and set the new scene for Orders
            Stage stage = (Stage) ordersButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(orderScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);
            stage.setTitle("Orders Management");
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            // Show an error alert if loading fails
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to load the Orders page.");
            alert.show();
        }
    }

    // Handles the logout action
    @FXML
    public void handleLogout(ActionEvent event) {
        try {
            // Load the home page FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/HomePage.fxml"));
            Parent homeScene = loader.load();

            // Get the current stage (window) and change the scene
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(homeScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);
            stage.setTitle("Home Page");

            // Show a logout confirmation alert
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Logged Out");
            alert.setHeaderText(null);
            alert.setContentText("You have been logged out successfully.");
            alert.showAndWait();

            // Show the new scene (home page)
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            // Show error if something goes wrong
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("An error occurred while logging out. Please try again.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleRemoveProduct() {
        try {
            // Load the Remove Product page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/AdminCategories/RemoveProduct.fxml"));
            Parent removeProductScene = loader.load();

            // Set the scene for the current stage
            Stage stage;
            stage = (Stage) removeButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(removeProductScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);
            stage.setTitle("Home Page");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Show an error alert if the page fails to load
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to load the Remove Product page.");
            alert.show();
        }
    }
@FXML
    private void handleUsers() {
        try {
            // Load the Remove Product page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/AdminCategories/Users.fxml"));
            Parent UsersScene = loader.load();

            // Set the scene for the current stage
            Stage stage;
            stage = (Stage) removeButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(UsersScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);
            stage.setTitle("Home Page");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Show an error alert if the page fails to load
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to load the Remove Product page.");
            alert.show();
        }
    }


    // Handles the "Product Modifications" button click



    @FXML
    public void initialize() {
        // Set the normal style of the logout button
        logoutButton.setStyle("-fx-background-color: #800080; -fx-text-fill: #F8F8FF;");

        // Hover effect for logout button
        logoutButton.setOnMouseEntered(event -> {
            logoutButton.setStyle("-fx-background-color: #D3A6FF; -fx-text-fill: #F8F8FF;");
        });
        logoutButton.setOnMouseExited(event -> {
            logoutButton.setStyle("-fx-background-color: #800080; -fx-text-fill: #F8F8FF;");
        });




        // Add hover effects for other buttons if needed
        setupHoverEffect(addButton);
        setupHoverEffect(removeButton);
        setupHoverEffect(ordersButton);
        setupHoverEffect(usersButton);
    }

    private void setupHoverEffect(Button button) {
        button.setOnMouseEntered(event -> button.setStyle("-fx-background-color: #E0E0E0; -fx-text-fill: #800080;"));
        button.setOnMouseExited(event -> button.setStyle("-fx-background-color: #F8F8F8; -fx-text-fill: #800080;"));
    }
}
