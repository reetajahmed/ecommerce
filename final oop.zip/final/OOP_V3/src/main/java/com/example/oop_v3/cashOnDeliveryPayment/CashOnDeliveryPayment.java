package com.example.oop_v3.cashOnDeliveryPayment;
import com.example.oop_v3.payments.Payments;

public class CashOnDeliveryPayment implements Payments {
    @Override
    public boolean paymentCompleted(double amount) {
        System.out.println("Processing Cash on Delivery for amount:" + amount+"EGP");
        return true;
    }
    @Override
    public void displayDetails() {
        System.out.println("Payment Method: Cash on Delivery");
    }
    @Override
    public String getMethodName() {
        return "Cash on Delivery";
    }
}
