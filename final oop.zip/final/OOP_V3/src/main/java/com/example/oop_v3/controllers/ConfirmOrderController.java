package com.example.oop_v3.controllers;
import com.example.oop_v3.customer.Customer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class ConfirmOrderController {

    private Customer loggedInCustomer;
    @FXML
    private Button cohomepagebutton;


    public void initialize(Customer customer) {
        loggedInCustomer = customer;

    }

    @FXML
    private void handlecohomepagebutton() {
        try {
            // Load the LoggedInHomePage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/loggedinHomePage.fxml"));
            Parent root = loader.load();

            LoggedinHomePageController controller = loader.getController();
            controller.emptycart(loggedInCustomer);

            // Get the current stage (window)
            Stage stage = (Stage) cohomepagebutton.getScene().getWindow(); // backButton is the ID of the back button

            // Set the new scene for the stage
            stage.setScene(new Scene(root));

            // Optionally, you can set the title of the new window
            stage.setTitle("Logged In Home Page");

            // Show the new scene
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the error (maybe show an alert or log it)
        }
    }
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
