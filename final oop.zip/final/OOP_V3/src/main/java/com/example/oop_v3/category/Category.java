package com.example.oop_v3.category;
import com.example.oop_v3.product.Product;

import java.util.ArrayList;
import java.util.List;

public class Category {
    private String categoryName;
    private String description;
    private List<Product> products;
    private String bgImageUrl;

    public Category() {
        this.products = new ArrayList<>(); // Initialize the list
    }

    public Category(String categoryName) {
        this.categoryName = categoryName;
        this.products = new ArrayList<>();

    }

    public Category(String categoryName, String description, String bgImageUrl) {
        this.categoryName = categoryName;
        this.description = description;
        this.bgImageUrl = bgImageUrl;
        this.products = new ArrayList<>();
    }

    public Category(String categoryName, String description) {
        this.categoryName = categoryName;
        this.description = description;
        this.products = new ArrayList<>(); // Initialize the list
    }

    // Getters and setters
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Function to get all products in this category
    public List<Product> getProducts() {
        return products;
    }
    public void setProducts(List<Product> products) {
        this.products = products;
    }
    public String getBgImageUrl() {
        return bgImageUrl;
    }

    public void setBgImageUrl(String bgImageUrl) {
        this.bgImageUrl = bgImageUrl;
    }

    // Static function to display all categories with numbers
    public static void displayCategories(List<Category> categories) {
        System.out.println("Available Categories:");
        int index = 1;
        for (Category category : categories) {
            System.out.println(index++ + ". " + category.getCategoryName() + ": " + category.getDescription());
        }
    }

    // Function to display all products in this category with numbers
    public void displayProducts() {
        if (products.isEmpty()) {
            System.out.println("No products available in the category: " + categoryName);
        } else {
            System.out.println("Products in " + categoryName + ":");
            int index = 1;
            for (Product product : products) {
                System.out.println("[" + index++ + "]" + product.getName() + "\n-Price: " + product.getPrice() + "\n-Stock: " + product.getStock());
            }
        }
    }
}