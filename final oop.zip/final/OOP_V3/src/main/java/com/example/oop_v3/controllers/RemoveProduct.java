package com.example.oop_v3.controllers;
import com.example.oop_v3.database.Database;
import com.example.oop_v3.category.Category;
import com.example.oop_v3.product.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveProduct {

    @FXML private ComboBox<String> categoryComboBox;
    @FXML private ListView<CheckBox> productListView;
    @FXML private Button removeButton;
    @FXML private Button back;
    private Database database = Database.getInstance();
    @FXML private Button gobackButton;

    @FXML
    public void handleGoBack(ActionEvent event) {
        try {
            // Load the home page FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/AdminCategories/adminpage.fxml"));
            Scene homeScene = new Scene(loader.load());

            // Get the current stage (window) and change the scene
            Stage stage = (Stage) gobackButton.getScene().getWindow();
            stage.setScene(homeScene);
            stage.setTitle("Back Page");

            // Show a logout confirmation alert
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Back to admin dashboard");
            alert.setHeaderText(null);
            alert.setContentText("You have gone to Admin Dashboard successfully.");
            alert.showAndWait();

            // Show the new scene (home page)
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            // Show error if something goes wrong
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("An error occurred while going back. Please try again.");
            alert.showAndWait();
        }
    }
    @FXML
    public void initialize() {
        gobackButton.setStyle("-fx-background-color: #800080; -fx-text-fill: #F8F8FF;");

        // Hover effect for logout button
        gobackButton.setOnMouseEntered(event -> {
            gobackButton.setStyle("-fx-background-color: #D3A6FF; -fx-text-fill: #F8F8FF;");
        });
        gobackButton.setOnMouseExited(event -> {
            gobackButton.setStyle("-fx-background-color: #800080; -fx-text-fill: #F8F8FF;");
        });
        List<String> categoryNames = database.getCategories().stream()
                .map(Category::getCategoryName)
                .collect(Collectors.toList());
        categoryComboBox.setItems(FXCollections.observableArrayList(categoryNames));
        categoryComboBox.setPromptText("Select a Category");

        // Handle category selection
        categoryComboBox.setOnAction(e -> loadProducts());

        // Handle product removal
        removeButton.setOnAction(e -> removeSelectedProducts());

    }



    private void loadProducts() {
        productListView.getItems().clear();

        String selectedCategoryName = categoryComboBox.getValue();
        if (selectedCategoryName != null) {
            Category category = database.findCategoryByName(selectedCategoryName);

            if (category != null && category.getProducts() != null) {
                List<Product> products = category.getProducts();

                ObservableList<CheckBox> productCheckBoxes = FXCollections.observableArrayList(
                        products.stream()
                                .map(product -> {
                                    CheckBox checkBox = new CheckBox(product.getName() + " ($" + product.getPrice() + ")");
                                    checkBox.setUserData(product);
                                    return checkBox;
                                })
                                .collect(Collectors.toList())
                );

                productListView.setItems(productCheckBoxes);
            }
        }
    }

    // Remove selected products from the category
    public void removeSelectedProducts() {
        String selectedCategoryName = categoryComboBox.getValue();
        if (selectedCategoryName != null) {
            Category category = database.findCategoryByName(selectedCategoryName);

            if (category != null) {
                ObservableList<CheckBox> checkBoxes = productListView.getItems();
                List<Product> productsToRemove = checkBoxes.stream()
                        .filter(CheckBox::isSelected)
                        .map(cb -> (Product) cb.getUserData())
                        .collect(Collectors.toList());

                // Remove products from the category and global product list
                productsToRemove.forEach(product -> {
                    category.getProducts().remove(product);
                    database.getProducts().remove(product);
                });

                loadProducts();
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Selected products removed successfully!");
                alert.show();
            }
        }
    }

}


