package com.example.oop_v3.controllers;

import com.example.oop_v3.creditCard.CreditCard;
import com.example.oop_v3.cashOnDeliveryPayment.CashOnDeliveryPayment;
import com.example.oop_v3.customer.Customer;
import com.example.oop_v3.payments.Payments;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;

import java.io.IOException;
import java.time.LocalDate;

public class PaymentController {

    private Customer loggedInCustomer;

    @FXML
    private RadioButton visaRadioButton;

    @FXML
    private RadioButton cashOnDeliveryRadioButton;

    @FXML
    private TextField cardNumberField;

    @FXML
    private TextField cardHolderNameField;

    @FXML
    private DatePicker expiryDatePicker;

    @FXML
    private TextField cvvField;

    @FXML
    private Button confirmOrderButton;

    @FXML
    private Button backToCheckoutButton;

    @FXML
    private ToggleGroup paymentMethodGroup;

    @FXML
    public void initialize(Customer customer) {

        loggedInCustomer = customer;
        // Group RadioButtons
        paymentMethodGroup = new ToggleGroup();
        visaRadioButton.setToggleGroup(paymentMethodGroup);
        cashOnDeliveryRadioButton.setToggleGroup(paymentMethodGroup);

        // Disable Visa fields initially
        disableVisaFields(true);

        // Add a listener to enable/disable fields based on payment method selection
        visaRadioButton.setOnAction(event -> disableVisaFields(false));
        cashOnDeliveryRadioButton.setOnAction(event -> disableVisaFields(true));
    }

    private void disableVisaFields(boolean disable) {
        cardNumberField.setDisable(disable);
        cardHolderNameField.setDisable(disable);
        expiryDatePicker.setDisable(disable);
        cvvField.setDisable(disable);
    }

    @FXML
    private void handleConfirmOrder(ActionEvent event) {
        if (visaRadioButton.isSelected()) {
            String cardNumber = cardNumberField.getText();
            String cardHolderName = cardHolderNameField.getText();
            String expiryDate = expiryDatePicker.getEditor().getText(); // Use .getEditor().getText() for manual input
            String cvv = cvvField.getText();

            if (validateCardDetails(cardNumber, cardHolderName, expiryDate, cvv)) {
                Payments visaPayment = new CreditCard(cardNumber, cardHolderName, expiryDate);
                visaPayment.displayDetails();
                showAlert(Alert.AlertType.INFORMATION, "Order Confirmed", "Your payment was successful!");
                navigateToConfirmOrderPage();
            }
        } else if (cashOnDeliveryRadioButton.isSelected()) {
            Payments cashPayment = new CashOnDeliveryPayment();
            cashPayment.displayDetails();
            //showAlert(Alert.AlertType.INFORMATION, "Order Confirmed", "Thanks for your purchase");
            navigateToConfirmOrderPage();

        } else {
            showAlert(Alert.AlertType.ERROR, "No Payment Method Selected", "Please select a payment method.");
        }

    }

    @FXML
    private void handleBackToCheckout(ActionEvent event) {
        try {
            // Load the CheckoutPage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/Checkout/Checkout.fxml"));
            Parent checkoutPage = loader.load();

            CheckoutPageController controller = loader.getController();
            controller.initialize(loggedInCustomer);

            // Get the current stage (window)
            Stage stage = (Stage) backToCheckoutButton.getScene().getWindow();

            // Set the new scene (checkout page) in the stage
            Scene scene = new Scene(checkoutPage);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load checkout page.");
        }
    }


    private boolean validateCardDetails(String cardNumber, String cardHolderName, String expiryDate, String cvv) {

        // Validate Card Holder Name (must be alphabetical only)
        if (cardHolderName == null || cardHolderName.trim().isEmpty() || !cardHolderName.matches("[a-zA-Z\\s]+")) {
            showAlert(Alert.AlertType.ERROR, "Invalid Cardholder Name", "Cardholder name must only contain letters and spaces.");
            return false;
        }

        // Validate Card Number (must be 16 digits and integer)
        if (!cardNumber.matches("\\d{16}")) {
            showAlert(Alert.AlertType.ERROR, "Invalid Card Number", "Card number must be 16 digits.");
            return false;
        }

        // Validate Expiry Date (must not be before 2024)
        if (expiryDate == null || expiryDate.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Invalid Expiry Date", "Please select an expiry date.");
            return false;
        }

        // Get the selected expiry date
        LocalDate expiryLocalDate = expiryDatePicker.getValue();

        if (expiryLocalDate == null || expiryLocalDate.isBefore(LocalDate.of(2024, 1, 1))) {
            showAlert(Alert.AlertType.ERROR, "Invalid Expiry Date", "Expiry date must be after or equal to January 2024.");
            return false;
        }

        // Validate CVV (must be 3 digits integer)
        if (!cvv.matches("\\d{3}")) {
            showAlert(Alert.AlertType.ERROR, "Invalid CVV", "CVV must be 3 digits.");
            return false;
        }

        return true;
    }

    private void navigateToConfirmOrderPage() {
        try {
            // Load the ConfirmOrder FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/Checkout/ConfirmOrder.fxml"));
            Parent root = loader.load();

            ConfirmOrderController controller = loader.getController();
            controller.initialize(loggedInCustomer);

            // Get the current stage (window)
            Stage stage = (Stage) confirmOrderButton.getScene().getWindow();

            // Set the new scene for the stage
            stage.setScene(new Scene(root));

            // Optionally, you can set the title of the new window
            stage.setTitle("Payment Page");

            // Show the new scene
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle the error (maybe show an alert or log it)
        }
    }



    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
