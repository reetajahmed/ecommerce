package com.example.oop_v3.controllers;

import com.example.oop_v3.database.Database;
import com.example.oop_v3.order.Order;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class OrderController {

    @FXML
    private TableView<Order> ordersTable;

    @FXML
    private TableColumn<Order, Integer> orderIdColumn;

    @FXML
    private TableColumn<Order, String> customerColumn;

    @FXML
    private TableColumn<Order, Double> totalAmountColumn;

    @FXML
    private ChoiceBox<String> sortChoiceBox;

    @FXML
    private Button gobackButton;

    private ObservableList<Order> ordersList;


    @FXML
    public void initialize() {
        // Set up table columns
        orderIdColumn.setCellValueFactory(new PropertyValueFactory<>("orderId"));
        customerColumn.setCellValueFactory(order ->
                new javafx.beans.property.SimpleStringProperty(order.getValue().getCustomer().getUsername()));
        totalAmountColumn.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));

        // Fetch orders from the database
        loadOrders();

        // Initialize sort options
        sortChoiceBox.setItems(FXCollections.observableArrayList("Newest to Oldest", "Oldest to Newest"));
        sortChoiceBox.getSelectionModel().selectFirst(); // Default selection
        sortChoiceBox.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> sortOrders(newValue));
    }

    private void loadOrders() {
        Database database = Database.getInstance();
        List<Order> orders = database.getOrders();
        orders.forEach(order -> System.out.println("Loaded Order: " + order));
        ordersList = FXCollections.observableArrayList(orders);
        ordersTable.setItems(ordersList);
    }


    private void sortOrders(String sortOption) {
        if (sortOption.equals("Newest to Oldest")) {
            ordersList.sort(Comparator.comparing(Order::getOrderId).reversed());
        } else if (sortOption.equals("Oldest to Newest")) {
            ordersList.sort(Comparator.comparing(Order::getOrderId));
        }
    }

    @FXML
    public void handleGoBack(ActionEvent event) {
        try {
            // Load the home page FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/AdminCategories/adminpage.fxml"));
            Parent homeScene = loader.load();

            // Get the current stage (window) and change the scene
            Stage stage = (Stage) gobackButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(homeScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.setTitle("Back Page");

            // Show a logout confirmation alert
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Back to admin dashboard");
            alert.setHeaderText(null);
            alert.setContentText("You have gone to Admin Dashboard successfully.");
            alert.showAndWait();

            // Show the new scene (home page)
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            // Show error if something goes wrong
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("An error occurred while going back. Please try again.");
            alert.showAndWait();
        }
    }
}
