package com.example.oop_v3.person;


public abstract class Person {
    public enum Gender{
        MALE,
        FEMALE
    }
    private String username;
    private String password;
    private String dateOfBirth;
    private String address;
    private Gender gender;
    public Person(){}
    public Person(String username,String password,String dateOfBirth,String address,Gender gender){
        this.username=username;
        this.password=password;
        this.dateOfBirth=dateOfBirth;
        this.address=address;
        this.gender=gender;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Gender getGender() {
        return gender;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getAddress() {
        return address;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public abstract void displayInfo();
}

