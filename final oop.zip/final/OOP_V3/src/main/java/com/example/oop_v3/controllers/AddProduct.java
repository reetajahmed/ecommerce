package com.example.oop_v3.controllers;

import com.example.oop_v3.category.Category;
import com.example.oop_v3.database.Database;
import com.example.oop_v3.product.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

public class AddProduct {
    @FXML private Button addproduct;

    private Database database;
    @FXML private Button gobackButton;

    @FXML
    private TextField nameField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField stockField;

    @FXML
    private TextField imageUrlField;

    @FXML
    private ComboBox<String> categoryComboBox;

    @FXML
    public void handleGoBack(ActionEvent event) {
        try {
            // Load the home page FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/AdminCategories/adminpage.fxml"));
            Parent homeScene = loader.load();

            // Get the current stage (window) and change the scene
            Stage stage = (Stage) gobackButton.getScene().getWindow();
            // Preserve current window size
            double currentWidth = stage.getWidth();
            double currentHeight = stage.getHeight();

            // Set the new scene with the preserved size
            Scene scene = new Scene(homeScene, currentWidth, currentHeight);
            stage.setScene(scene);
            // Explicitly set the stage size
            stage.setWidth(currentWidth);
            stage.setHeight(currentHeight);

            stage.setTitle("Back Page");

            // Show a logout confirmation alert
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Back to admin dashboard");
            alert.setHeaderText(null);
            alert.setContentText("You have gone to Admin Dashboard successfully.");
            alert.showAndWait();

            // Show the new scene (home page)
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            // Show error if something goes wrong
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("An error occurred while going back. Please try again.");
            alert.showAndWait();
        }
    }

    @FXML
    public void initialize() {
        database = Database.getInstance();
        gobackButton.setStyle("-fx-background-color: #800080; -fx-text-fill: #F8F8FF;");

        // Hover effect for logout button
        gobackButton.setOnMouseEntered(event -> {
            gobackButton.setStyle("-fx-background-color: #D3A6FF; -fx-text-fill: #F8F8FF;");
        });
        gobackButton.setOnMouseExited(event -> {
            gobackButton.setStyle("-fx-background-color: #800080; -fx-text-fill: #F8F8FF;");
        });


        // Populate the ComboBox with categories from the database


        for (Category category : Database.getInstance().getCategories()) {
            categoryComboBox.getItems().add(category.getCategoryName());
        }
    }


    @FXML
    public void handleAddProduct(ActionEvent event) {
        try {
            if (database == null) {
                throw new IllegalStateException("Database is not initialized.");
            }

            // Get product details from the form
            String productName = nameField.getText().trim();  // Trim spaces
            String priceText = priceField.getText().trim();
            String stockText = stockField.getText().trim();
            String productImageUrl = imageUrlField.getText().trim();
            String selectedCategory = categoryComboBox.getValue();

            // Check if any field is empty or not selected
            if (productName.isEmpty() || priceText.isEmpty() || stockText.isEmpty() || productImageUrl.isEmpty() || selectedCategory == null) {
                throw new IllegalArgumentException("All fields must be filled.");
            }

            // Try parsing price and stock values
            double productPrice;
            int productStock;

            try {
                productPrice = Double.parseDouble(priceText);
                productStock = Integer.parseInt(stockText);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Price and stock must be valid numbers.");
            }

            // Check if price and stock are positive numbers
            if (productPrice <= 0 || productStock <= 0) {
                throw new IllegalArgumentException("Price and stock must be positive numbers.");
            }

            // Find the selected category from the database
            Category category = database.findCategoryByName(selectedCategory);
            if (category == null) {
                throw new IllegalArgumentException("Category not found.");
            }

            // Create a new product
            Product newProduct = new Product(database.getProducts().size() + 1, productName, productPrice, productStock, category, productImageUrl);

            // Add the product to the database
            database.addProduct(newProduct, selectedCategory);

            // Show success alert
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Product Added");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Product has been added successfully to the database.");
            successAlert.showAndWait();

        } catch (IllegalArgumentException e) {
            // Handle missing or invalid inputs
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Input Error");
            errorAlert.setHeaderText(null);
            errorAlert.setContentText(e.getMessage());
            errorAlert.showAndWait();
        } catch (Exception e) {
            // Handle general errors
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Error");
            errorAlert.setHeaderText(null);
            errorAlert.setContentText("An unexpected error occurred: " + e.getMessage());
            errorAlert.showAndWait();
        }
    }

}



