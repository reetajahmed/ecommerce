package com.example.oop_v3.controllers;

import com.example.oop_v3.customer.Customer;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
public class CheckoutPageController {
    private Customer loggedInCustomer;

    @FXML private TextField firstNameTextField;
    @FXML private TextField lastNameTextField;
    @FXML private TextField addressTextField;
    @FXML private TextField postalCodeTextField;
    @FXML private TextField cityTextField;
    @FXML private TextField phoneNumberTextField;
    @FXML private TextField emailTextField;

    @FXML private Button checkoutButton;
    @FXML private Button backButton;

    public void initialize(Customer customer) {
        loggedInCustomer = customer;

    }

    @FXML
    private void handleCheckout() {
        if (!isValidInput()) {
            return;  // If input is invalid, exit the method and prevent page navigation
        }

        String firstName = firstNameTextField.getText().trim();
        String lastName = lastNameTextField.getText().trim();
        String address = addressTextField.getText().trim();
        String postalCode = postalCodeTextField.getText().trim();
        String city = cityTextField.getText().trim();
        String phoneNumber = phoneNumberTextField.getText().trim();
        String email = emailTextField.getText().trim();

        System.out.println("Checkout successful!");
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Address: " + address);
        System.out.println("Postal Code: " + postalCode);
        System.out.println("City: " + city);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Email: " + email);

        showAlert(AlertType.INFORMATION, "Success", "Checkout completed successfully.");

        try {
            // Load the Payment FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/Checkout/Paymentt.fxml"));
            Parent root = loader.load();

            PaymentController controller = loader.getController();
            controller.initialize(loggedInCustomer);

            // Get the current stage (window)
            Stage stage = (Stage) checkoutButton.getScene().getWindow();

            // Set the new scene for the stage
            stage.setScene(new Scene(root));

            // Optionally, you can set the title of the new window
            stage.setTitle("Payment Page");

            // Show the new scene
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the error (maybe show an alert or log it)
        }
    }


    @FXML
    private void handleBack() {

        try {
            // Load the LoggedInHomePage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/oop_v3/HomePage/loggedinHomePage.fxml"));
            Parent root = loader.load();

            LoggedinHomePageController controller = loader.getController();
            controller.initialize(loggedInCustomer);

            // Get the current stage (window)
            Stage stage = (Stage) backButton.getScene().getWindow(); // backButton is the ID of the back button

            // Set the new scene for the stage
            stage.setScene(new Scene(root));

            // Optionally, you can set the title of the new window
            stage.setTitle("Logged In Home Page");

            // Show the new scene
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the error (maybe show an alert or log it)
        }

    }


    private boolean isValidInput() {
        // Check for empty fields
        if (firstNameTextField.getText().trim().isEmpty()) {
            showAlert(AlertType.WARNING, "Invalid Input", "First Name cannot be empty.");
            return false;
        }
        if (lastNameTextField.getText().trim().isEmpty()) {
            showAlert(AlertType.WARNING, "Invalid Input", "Last Name cannot be empty.");
            return false;
        }
        if (addressTextField.getText().trim().isEmpty()) {
            showAlert(AlertType.WARNING, "Invalid Input", "Shipping Address cannot be empty.");
            return false;
        }
        if (postalCodeTextField.getText().trim().isEmpty()) {
            showAlert(AlertType.WARNING, "Invalid Input", "Postal Code cannot be empty.");
            return false;
        } else if (!postalCodeTextField.getText().trim().matches("\\d+")) {  // Check if postal code is all digits
            showAlert(AlertType.WARNING, "Invalid Input", "Postal Code must only contain digits.");
            return false;
        }

        if (cityTextField.getText().trim().isEmpty()) {
            showAlert(AlertType.WARNING, "Invalid Input", "City cannot be empty.");
            return false;
        }
        if (phoneNumberTextField.getText().trim().isEmpty()) {
            showAlert(AlertType.WARNING, "Invalid Input", "Phone Number cannot be empty.");
            return false;
        } else if (!phoneNumberTextField.getText().trim().matches("\\d+")) {  // Check if phone number is all digits
            showAlert(AlertType.WARNING, "Invalid Input", "Phone Number must only contain digits.");
            return false;
        }

        if (emailTextField.getText().trim().isEmpty()) {
            showAlert(AlertType.WARNING, "Invalid Input", "Email cannot be empty.");
            return false;
        }
        return true;
    }



    private void showAlert(AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


}
